# Arquitetura de Referência de IPM – CAIXA

Versão de 4 de novembro de 2026 · Autor: Cleyton

Este documento descreve a arquitetura de referência de IPM (Infrastructure Performance Management, ou Gerenciamento de Desempenho de Infraestrutura) da CAIXA: o que monitorar na infraestrutura, como coletar e analisar esses dados e como agir antes que o cliente perceba um problema. Foi escrito para qualquer pessoa, técnica ou não; os termos técnicos estão explicados no glossário, ao final.

> Versão em PDF: [Arquitetura-de-Referencia-IPM-CAIXA.pdf](Arquitetura-de-Referencia-IPM-CAIXA.pdf)

## Sumário

1. [O que é IPM](#1-o-que-é-ipm)
2. [Para que serve o IPM](#2-para-que-serve-o-ipm)
3. [O que o IPM monitora](#3-o-que-o-ipm-monitora)
4. [Arquitetura de referência](#4-arquitetura-de-referência)
5. [As camadas, uma a uma](#5-as-camadas-uma-a-uma)
6. [Como o IPM trabalha junto com APM e NPM](#6-como-o-ipm-trabalha-junto-com-apm-e-npm)
7. [Do alerta à prevenção](#7-do-alerta-à-prevenção)
8. [Ferramentas de mercado por camada](#8-ferramentas-de-mercado-por-camada)
9. [Segurança, acesso e retenção](#9-segurança-acesso-e-retenção)
10. [Como implantar](#10-como-implantar)
11. [Glossário](#11-glossário)
12. [Fontes](#fontes)

## 1. O que é IPM

IPM é a prática de acompanhar, medir e analisar a saúde, a disponibilidade e o uso dos recursos de infraestrutura, físicos e em nuvem. Em outras palavras: é saber, a todo momento, se as máquinas onde os sistemas da CAIXA rodam estão bem.

**Uma analogia.** Pense numa agência bancária. O APM observa o atendimento: se o cliente foi bem atendido e rápido. O NPM observa as ruas que levam até a agência: se o caminho está livre. O IPM observa o prédio: energia, ar-condicionado, espaço, elevadores. Se o prédio falha, o atendimento piora, mesmo com bons atendentes.

![As três camadas da observabilidade: APM, IPM e NPM](imagens/01-camadas-observabilidade.png)

As três camadas usam os mesmos tipos de dado (logs, métricas e traces). O IPM trabalha principalmente com métricas, que são números medidos ao longo do tempo, como "uso de CPU em 85%".

## 2. Para que serve o IPM

O IPM tem três papéis. Toda a arquitetura deste documento existe para cumprir esses três.

| Papel | O que significa | Exemplo prático |
| --- | --- | --- |
| Visibilidade de recursos | Saber quanto de cada recurso está sendo usado e onde estão os gargalos | Um servidor do sistema de cartões está com o disco 95% cheio |
| Correlação de eventos | Quando uma aplicação fica lenta, dizer se a causa está na infraestrutura | O app ficou lento às 10h05; no mesmo minuto, a memória do banco de dados acabou |
| Prevenção de falhas | Medir continuamente para prever a degradação antes que o cliente sinta | No ritmo atual, o storage enche em 12 dias: ampliar agora |

**O que muda para a CAIXA:** a equipe deixa de descobrir problemas pela reclamação do cliente e passa a descobri-los pelos dados, muitas vezes antes de virarem incidente.

## 3. O que o IPM monitora

O IPM cobre todo recurso físico ou virtual em que um sistema da CAIXA roda, no datacenter próprio e na nuvem. Para cada tipo, poucas métricas já dizem quase tudo sobre a saúde dele.

| Recurso | O que é | Métricas essenciais | Sinal de alerta típico |
| --- | --- | --- | --- |
| Servidores físicos | Máquinas instaladas no datacenter | CPU, memória, disco, temperatura, fontes de energia | CPU acima do normal por vários minutos |
| Máquinas virtuais (VMs) | Servidores "de software" que dividem um servidor físico | CPU, memória, disco e o quanto a VM espera pelo servidor físico | VM esperando recurso que outra VM está usando |
| Containers e Kubernetes | Pacotes leves de aplicação e a plataforma que os organiza | CPU e memória por container, reinicializações, nós disponíveis | Container reiniciando repetidamente por falta de memória |
| Storage (armazenamento) | Discos e sistemas onde os dados ficam guardados | Espaço ocupado, velocidade de leitura e gravação, tempo de resposta | Tempo de resposta do disco subindo |
| Mainframe | Computador central de grande porte, onde ficam sistemas críticos | Uso de processador (MIPS), memória, filas e tempo de resposta dos subsistemas | Processador perto do limite contratado |
| Bancos de dados (infraestrutura) | Servidores que guardam as informações dos sistemas | Conexões, memória, espaço, tempo de resposta | Conexões esgotadas |
| Nuvem | Recursos contratados de provedores externos | As mesmas acima, mais limites de cota e custo | Cota de recurso perto do fim |
| Ambiente físico | Energia e refrigeração do datacenter | Temperatura, carga de energia, status de nobreak | Temperatura da sala subindo |

**Regra prática:** para quase todo recurso, quatro perguntas bastam. Está ligado? Quanto está sendo usado? Está sobrecarregado (com fila de espera)? Está dando erro?

## 4. Arquitetura de referência

A arquitetura tem seis camadas, lidas de cima para baixo: o dado nasce no recurso monitorado e termina numa ação da equipe. O pipeline é o centro: tudo passa por ele, o que mantém os dados padronizados e permite trocar ferramentas sem refazer a coleta.

![Arquitetura de referência de IPM em seis camadas](imagens/02-arquitetura-referencia.png)

O inventário diz a qual sistema e equipe cada medição pertence, e os dados de APM e NPM entram na análise para apontar a causa raiz. A seção 5 explica cada camada.

## 5. As camadas, uma a uma

Cada camada tem uma função simples. Juntas, elas transformam milhares de medições por segundo em poucas informações úteis.

| Camada | Em uma frase | Como funciona |
| --- | --- | --- |
| 1. Fontes | O que é observado | Os recursos da seção 3: servidores, VMs, containers, storage, mainframe, nuvem |
| 2. Coleta | Quem mede | Agentes (pequenos programas instalados no servidor) ou coleta sem agente, que consulta o equipamento a distância (SNMP, APIs da nuvem e da virtualização). Padrão recomendado: OpenTelemetry |
| 3. Pipeline | Quem organiza | Um ponto central recebe tudo, padroniza nomes, acrescenta contexto (qual sistema, ambiente e equipe responsável), descarta o que não é útil e envia ao destino. Uma fila guarda os dados se o destino ficar fora do ar |
| 4. Armazenamento | Onde os dados ficam | Um banco de séries temporais guarda as métricas (número, data e hora). Dados antigos vão para um armazenamento mais barato |
| 5. Análise | Quem interpreta | Aprende o comportamento normal de cada recurso, aponta o que foge do normal e projeta o crescimento de uso |
| 6. Ação | O que se faz com a informação | Painéis, alertas para a equipe de plantão, abertura automática de chamado e, quando seguro, correções automáticas |

**Dois apoios que atravessam todas as camadas:**

- **Inventário (CMDB):** o cadastro que diz qual servidor atende qual sistema e quem é o responsável. Sem ele, um alerta diz "servidor X com problema", mas não diz quem é afetado.
- **Segurança e governança:** quem pode ver o quê, por quanto tempo os dados ficam guardados e como isso atende às normas (seção 9).

## 6. Como o IPM trabalha junto com APM e NPM

Sozinho, o IPM diz que um servidor está sobrecarregado. Junto com APM e NPM, ele diz que o servidor sobrecarregado é a causa da lentidão que o cliente está sentindo. Para isso, as três ferramentas precisam usar os mesmos nomes de sistemas e servidores, o mesmo relógio e o mesmo inventário.

**Exemplo: o aplicativo está lento para mostrar a fatura do cartão**

1. **APM percebe:** o tempo de resposta da tela de fatura sobe de 1 para 6 segundos às 10h05.
2. **APM aponta o trecho:** a demora está na consulta ao banco de dados de faturas.
3. **NPM descarta a rede:** a latência entre aplicação e banco continua normal.
4. **IPM encontra a causa:** o storage do banco de dados está com o tempo de resposta cinco vezes acima do normal desde 10h03.
5. **Inventário mostra o impacto:** o mesmo storage atende outros dois sistemas, que também começam a degradar.
6. **Equipe certa acionada:** o chamado vai direto para a equipe de storage, com os gráficos anexados, em vez de passar por várias equipes.

Os números acima são ilustrativos. O ganho real está no passo 6: o tempo gasto descobrindo "de quem é o problema" cai muito.

## 7. Do alerta à prevenção

O objetivo é sair do modelo "avisa quando caiu" para o modelo "avisa antes de cair". Isso acontece em níveis, e cada nível depende do anterior.

| Nível | Como funciona | Exemplo |
| --- | --- | --- |
| 1. Reativo | Alerta quando algo para | "Servidor X não responde" |
| 2. Por limite | Alerta quando uma métrica passa de um valor fixo | "Disco acima de 90%" |
| 3. Por comportamento | Alerta quando o recurso foge do seu padrão normal para aquele dia e horário | "CPU 40% acima do normal para uma segunda às 10h" |
| 4. Preditivo | Projeta a tendência e avisa antes do limite | "No ritmo atual, a memória acaba em 3 dias" |
| 5. Automatizado | Executa uma correção conhecida sem esperar alguém | Ampliar automaticamente o número de containers num pico de uso |

### Boas regras de alerta

- **Todo alerta precisa ter uma ação.** Se ninguém precisa fazer nada, é informação para painel, não alerta.
- **Alerta pelo efeito, não só pela causa.** "CPU alta" sozinha pode ser normal; "CPU alta e sistema lento" exige ação.
- **Respeitar o calendário da CAIXA.** Pagamento de benefícios, início do mês e datas comerciais têm picos esperados; o padrão normal deve considerar isso.
- **Silêncio também é alerta.** Se um servidor para de enviar métricas, isso deve avisar, e não parecer que está tudo bem.
- **Severidade clara:** crítico (afeta cliente agora), alto (vai afetar em breve), médio (risco), baixo (informativo).

### Gestão de capacidade

Com o histórico guardado, o IPM projeta quando cada recurso vai acabar. Isso permite planejar compras, contratações de nuvem e ampliações com antecedência, em vez de comprar com urgência depois de um incidente. Recomenda-se uma revisão mensal de capacidade com as equipes de infraestrutura.

## 8. Ferramentas de mercado por camada

A arquitetura de referência não depende de um produto. A tabela mostra exemplos de mercado para cada camada; a escolha deve considerar as ferramentas que a CAIXA já possui.

| Camada | Exemplos open source | Exemplos comerciais |
| --- | --- | --- |
| Coleta em servidores, VMs e containers | OpenTelemetry Collector, Prometheus node exporter, Telegraf | Agentes de Dynatrace, Datadog, Zabbix (open source com suporte comercial) |
| Coleta de virtualização e storage | Exporters de VMware e de storage para Prometheus | VMware Aria Operations, ferramentas dos fabricantes de storage |
| Coleta no mainframe | z/OS OpenTelemetry Emitter (IBM) | IBM Z OMEGAMON, IBM Z Observability Connect |
| Pipeline | OpenTelemetry Collector (gateway), Apache Kafka | Cribl Stream, Confluent |
| Armazenamento de métricas | Prometheus com Grafana Mimir ou Thanos, VictoriaMetrics | Backend da ferramenta comercial escolhida |
| Análise e anomalias | Regras e modelos próprios, Grafana Machine Learning | Dynatrace Davis, Splunk ITSI, IBM Z Anomaly Analytics |
| Painéis e alertas | Grafana, Alertmanager | Dynatrace, Datadog, Splunk Observability |
| Chamados e inventário | GLPI, iTop | ServiceNow (ITSM e CMDB) |

**Recomendação:** usar OpenTelemetry na coleta e no pipeline, qualquer que seja a ferramenta de análise. Assim a CAIXA pode trocar ou combinar ferramentas no futuro sem reinstalar a coleta em todos os servidores.

## 9. Segurança, acesso e retenção

O IPM coleta dados de quase todos os servidores da CAIXA, então ele também precisa ser protegido. A regra principal: métricas de infraestrutura não devem carregar dados de clientes.

- **Sem dados de clientes:** nomes, CPF, números de cartão e senhas nunca entram nas métricas nem nos logs do IPM. Se aparecerem por engano, são removidos no pipeline.
- **Comunicação protegida:** todo envio de dados entre coletores, pipeline e armazenamento é criptografado.
- **Acesso por perfil:** cada equipe vê o que precisa. Alterações de configuração e de alertas exigem login corporativo com autenticação forte e ficam registradas.
- **Dados no Brasil:** os dados ficam em ambiente no país. Se houver uso de nuvem, a contratação segue as regras do Banco Central para serviços em nuvem.
- **Normas:** o IPM ajuda a atender a [Resolução CMN 4.893](https://okai.com.br/documento/2021-02-26/resolucao-cmn-n-4-893), cuja versão atualizada pela Resolução CMN 5.274/2025 inclui rastreabilidade e prevenção e detecção de intrusão entre os controles mínimos. Para ambientes com dados de cartão, o [PCI DSS v4.0.1](https://www.scrut.io/hub/pci-dss/pci-dss-4-0-1-guide) também se aplica.

### Por quanto tempo guardar

| Dado | Tempo sugerido | Motivo |
| --- | --- | --- |
| Métricas em detalhe (a cada 15 a 60 segundos) | 30 dias | Investigar incidentes recentes |
| Métricas resumidas (médias por hora) | 13 meses | Comparar com o mesmo mês do ano anterior e planejar capacidade |
| Logs de infraestrutura | 90 dias | Investigação técnica |
| Logs de auditoria e segurança | Conforme a política de segurança da CAIXA (no mínimo 12 meses em ambientes PCI) | Exigência normativa |

Os prazos são sugestões iniciais e devem ser confirmados com as áreas de segurança e conformidade.

## 10. Como implantar

A implantação vai em quatro fases, e cada uma só começa quando o portão anterior é cumprido. A duração de cada fase depende do levantamento feito na fase 0.

![Roadmap de implantação do IPM em quatro fases e três portões](imagens/03-roadmap.png)

A fase 1 começa pelos sistemas mais críticos para o cliente, porque é onde um problema de infraestrutura custa mais.

| Portão | Critério para seguir em frente |
| --- | --- |
| G1 | Padrão de coleta (OpenTelemetry), padrão de nomes e ferramentas aprovados pelas áreas de infraestrutura e segurança |
| G2 | Todos os servidores dos sistemas críticos enviando métricas, com painéis e alertas funcionando |
| G3 | Todos os recursos monitorados cadastrados no inventário, com sistema e equipe responsável |

### Primeiros passos

- [ ] Listar os sistemas mais críticos e os servidores que os sustentam
- [ ] Levantar as ferramentas de monitoramento que a CAIXA já usa
- [ ] Definir o padrão de nomes para servidores, sistemas e ambientes
- [ ] Validar com segurança e conformidade as regras da seção 9
- [ ] Escolher um sistema piloto para a fase 1

## 11. Glossário

| Termo | Significado |
| --- | --- |
| Agente | Pequeno programa instalado num servidor para medir e enviar dados |
| Alerta | Aviso automático enviado a uma equipe quando algo exige ação |
| APM | Application Performance Management: monitoramento das aplicações e da experiência do usuário |
| CMDB | Banco de dados de configuração: o inventário de servidores, sistemas e responsáveis |
| Container | Pacote leve que leva uma aplicação e tudo de que ela precisa para rodar |
| CPU | Processador: a parte do computador que executa os cálculos |
| IPM | Infrastructure Performance Management: monitoramento da saúde e do uso da infraestrutura |
| ITSM | Gestão de serviços de TI; na prática, o sistema de chamados |
| Kafka | Software de fila que guarda dados em trânsito para que nada se perca |
| Kubernetes | Plataforma que organiza e distribui containers entre servidores |
| Latência | Tempo que um dado leva para ir de um ponto a outro |
| Linha de base | O comportamento normal de um recurso, aprendido a partir do histórico |
| Log | Registro em texto de um acontecimento num sistema |
| Mainframe | Computador central de grande porte, usado para sistemas críticos |
| Métrica | Número medido ao longo do tempo, como uso de CPU ou espaço em disco |
| MIPS | Medida de capacidade de processamento do mainframe |
| NPM | Network Performance Management: monitoramento da rede |
| Observabilidade | Capacidade de entender o que acontece dentro dos sistemas a partir dos dados que eles produzem |
| OpenTelemetry | Padrão aberto e gratuito para coletar e enviar métricas, logs e traces |
| Pipeline | Caminho central por onde os dados passam para serem organizados e encaminhados |
| SNMP | Protocolo usado para consultar equipamentos de rede e servidores a distância |
| Storage | Equipamento ou sistema onde os dados ficam armazenados |
| Trace | Registro do caminho completo de uma transação pelos sistemas |
| VM | Máquina virtual: um servidor criado por software dentro de um servidor físico |

## Fontes

- [Observabilidade de TI: NPM, IPM e APM (CITSmart)](https://citsmart.com.br/observabilidade-de-ti-npm-ipm-apm/)
- [Introdução ao monitoramento de sistemas e observabilidade (Nextwave)](https://nextwave.education/introducao-ao-monitoramento-de-sistemas-e-observabilidade/)
- [Sistemas distribuídos: observabilidade, telemetria e monitoramento (Medium)](https://medium.com/@marcelomg21/sistemas-distribu%C3%ADdos-observabilidade-telemetria-e-monitoramento-46d579d050b1)
- [Resolução CMN 4.893 com alterações da CMN 5.274/2025 (Okai)](https://okai.com.br/documento/2021-02-26/resolucao-cmn-n-4-893)
- [PCI DSS v4.0.1 (Scrut)](https://www.scrut.io/hub/pci-dss/pci-dss-4-0-1-guide)
- [z/OS OpenTelemetry Emitter (IBM)](https://www.ibm.com/docs/en/SSLTBW_3.2.0/com.ibm.zos.v3r2.grbdu00/otelemitter.htm)
- [OpenTelemetry no IBM Z (IBM Community)](https://community.ibm.com/community/user/blogs/matthew-leming1/2025/11/07/opentelemetry-on-ibm-z)
